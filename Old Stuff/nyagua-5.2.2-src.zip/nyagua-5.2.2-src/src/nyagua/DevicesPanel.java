/*
 * Nyagua - Aquarium Manager
 *    Copyright (C) 2012 Rudi Giacomini Pilon
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

/*
 * DevicesPanel.java
 *
 * Created on 14-giu-2012, 13.58.58
 */
package nyagua;

import dispatching.Watched;
import dispatching.Watcher;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import nyagua.data.Device;
import nyagua.data.Setting;

/**
 *
 * @author rudigiacomini
 */
public class DevicesPanel extends javax.swing.JPanel {
    
    //Connect listener to application bus
    ActionListener al = new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getID()==Watched.AQUARIUM_CLICKED){
                 if (Global.AqID != 0) {
                     populateTable();
                 }
                 else {
                     emptyTable();
                 }
            } else if(e.getID()==Watched.REQUEST_CLEAN_ALL_FIELDS){
                CleanAllFields();
            }            
        }
    };            
    Watcher settingWatch=new Watcher(al);
    
     /** Creates new form DevicesPanel */
    public DevicesPanel() {
        initComponents();
        initCutAndPaste(); 
        Watched nyMessages=Watched.getInstance();
        nyMessages.addObserver(settingWatch);        
              
        devicesTable.setTableHeader(
                new JTableHeader(devicesTable.getColumnModel()) {

            @Override
            public void setDraggedColumn(TableColumn column) {
              boolean finished = draggedColumn != null && column == null;
              super.setDraggedColumn(column);
              if (finished) {
                onColumnChange(devicesTable); 
              }
            }

            private void onColumnChange(JTable devicesTable) {
                Setting s = Setting.getInstance();
                s.setTableOrder("devicestable", devicesTable);
            }
          });
        
    }
    
    /**
     * Cleans all fields
     */
    private void CleanAllFields () {
         JTextField[] jtfList5 = {devicesIdTextField, devicesDeviceTextField, 
             devicesBrandTextField, devicesWTextField, devicesNotesTextField, 
            devicesOnPeriodTextField,devicesQtyTextField};
         
        Util.CleanTextFields(jtfList5);
    }
    
    /**
     * populate the table
     */
    static private void populateTable(){
        Device.populateTable(devicesTable);
    }
    
    /**
     * Empties a jTable assigning null model
     *
     */
    private static void emptyTable (){
        DefaultTableModel dm = new DefaultTableModel();
        String tableData[][] = {{null}};
        String[] nameHeader = {java.util.ResourceBundle.getBundle(
                "nyagua/Bundle").getString("NO_SELECTION")};
        dm.setDataVector(tableData, nameHeader);
        devicesTable.setModel(dm);
    }
    
    /**
     * Load tables widths
     */
    static void loadTablesSettings(){
        Setting s=Setting.getInstance();        
        int l = Device.CAPTIONS.length;
        int [] widths=s.getTableWidths("devicestable", l);//NOI18N
        Device.setColWidth(widths);
        TablesUtil.setColSizes(devicesTable,widths );
    }
    
    /**
     * Save tables widths
     */
    static void saveTableSettings(){
        Setting s=Setting.getInstance();
        s.setTableWidths("devicestable", devicesTable);//NOI18N
    }
    
    /**
     * refresh all fields when table selection change
     */
    private void refreshFields(){
        int recId = TablesUtil.getIdFromTable(
                devicesTable, devicesTable.getSelectedRow());
                
        Device dev=Device.getById(recId);
        devicesIdTextField.setText(Integer.toString(dev.getId()));
        devicesDeviceTextField.setText(dev.getName());
        devicesBrandTextField.setText(dev.getBrand());
        devicesWTextField.setText(dev.getWattage());
        devicesNotesTextField.setText(dev.getNotes());
        devicesOnPeriodTextField.setText(dev.getOnPeriod()); 
        devicesQtyTextField.setText(dev.getQty());
    }
    
   

    /** This method is called from within the constructor to
     * initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is
     * always regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {
        java.awt.GridBagConstraints gridBagConstraints;

        devicesDeviceTextField = new javax.swing.JTextField();
        devicesIdTextField = new javax.swing.JTextField();
        devicesDeviceLabel = new javax.swing.JLabel();
        devicesWTextField = new javax.swing.JTextField();
        devicesWLabel = new javax.swing.JLabel();
        devicesNotesTextField = new javax.swing.JTextField();
        devicesNotesLabel = new javax.swing.JLabel();
        devicesBrandTextField = new javax.swing.JTextField();
        devicesBrandLabel = new javax.swing.JLabel();
        devicesOnPeriodLabel = new javax.swing.JLabel();
        devicesOnPeriodTextField = new javax.swing.JTextField();
        devicesQtyLabel = new javax.swing.JLabel();
        devicesQtyTextField = new javax.swing.JTextField();
        jScrollPane7 = new javax.swing.JScrollPane();
        devicesTable = new javax.swing.JTable();
        devicesIdLabel = new javax.swing.JLabel();
        jToolBar6 = new javax.swing.JToolBar();
        devicesClearButton = new javax.swing.JButton();
        devicesSaveButton = new javax.swing.JButton();
        jSeparator5 = new javax.swing.JToolBar.Separator();
        devicesDeleteButton = new javax.swing.JButton();
        jSeparator11 = new javax.swing.JToolBar.Separator();
        devicesConsumButton = new javax.swing.JButton();
        jSeparator16 = new javax.swing.JToolBar.Separator();
        devicesSearchButton = new javax.swing.JButton();
        devicesSearchState = new javax.swing.JButton();
        devicesNoSearchButton = new javax.swing.JButton();

        setAlignmentX(0.0F);
        setAlignmentY(0.0F);
        setLayout(new java.awt.GridBagLayout());

        devicesDeviceTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesDeviceTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 3;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 261;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 15);
        add(devicesDeviceTextField, gridBagConstraints);

        devicesIdTextField.setEditable(false);
        devicesIdTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesIdTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.ipadx = 30;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesIdTextField, gridBagConstraints);

        java.util.ResourceBundle bundle = java.util.ResourceBundle.getBundle("nyagua/Bundle"); // NOI18N
        devicesDeviceLabel.setText(bundle.getString("Ny.devicesDeviceLabel.text")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 2;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesDeviceLabel, gridBagConstraints);

        devicesWTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesWTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        devicesWTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                devicesWTextFieldKeyTyped(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.ipadx = 50;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesWTextField, gridBagConstraints);

        devicesWLabel.setText(bundle.getString("Ny.devicesWLabel.text")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesWLabel, gridBagConstraints);

        devicesNotesTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesNotesTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.gridwidth = 5;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 395;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 15);
        add(devicesNotesTextField, gridBagConstraints);

        devicesNotesLabel.setText(bundle.getString("Notes_")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 3;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesNotesLabel, gridBagConstraints);

        devicesBrandTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesBrandTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.gridwidth = 3;
        gridBagConstraints.ipadx = 248;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesBrandTextField, gridBagConstraints);

        devicesBrandLabel.setText(bundle.getString("Ny.devicesBrandLabel.text")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 2;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesBrandLabel, gridBagConstraints);

        devicesOnPeriodLabel.setText(bundle.getString("Ny.devicesOnPeriodLabel.text")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesOnPeriodLabel, gridBagConstraints);

        devicesOnPeriodTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesOnPeriodTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        devicesOnPeriodTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                devicesOnPeriodTextFieldKeyTyped(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 1;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 30;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesOnPeriodTextField, gridBagConstraints);

        devicesQtyLabel.setText(bundle.getString("QTY")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 4;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesQtyLabel, gridBagConstraints);

        devicesQtyTextField.setMinimumSize(new java.awt.Dimension(30, 19));
        devicesQtyTextField.setPreferredSize(new java.awt.Dimension(80, 19));
        devicesQtyTextField.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyTyped(java.awt.event.KeyEvent evt) {
                devicesQtyTextFieldKeyTyped(evt);
            }
        });
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 5;
        gridBagConstraints.gridy = 4;
        gridBagConstraints.ipadx = 50;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.WEST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 15);
        add(devicesQtyTextField, gridBagConstraints);

        devicesTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null}
            },
            new String [] {
                "-- No selection --"
            }
        ));
        devicesTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_OFF);
        devicesTable.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                devicesTableMouseClicked(evt);
            }
        });
        devicesTable.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                devicesTableKeyReleased(evt);
            }
        });
        jScrollPane7.setViewportView(devicesTable);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 5;
        gridBagConstraints.gridwidth = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.BOTH;
        gridBagConstraints.ipadx = 613;
        gridBagConstraints.ipady = 240;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        gridBagConstraints.weightx = 1.0;
        gridBagConstraints.weighty = 1.0;
        gridBagConstraints.insets = new java.awt.Insets(15, 15, 15, 15);
        add(jScrollPane7, gridBagConstraints);

        devicesIdLabel.setText(bundle.getString("ID_")); // NOI18N
        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 1;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.EAST;
        gridBagConstraints.insets = new java.awt.Insets(5, 5, 5, 5);
        add(devicesIdLabel, gridBagConstraints);

        jToolBar6.setFloatable(false);
        jToolBar6.setRollover(true);

        devicesClearButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/btn_clear.png"))); // NOI18N
        devicesClearButton.setToolTipText(bundle.getString("Clear_Fields")); // NOI18N
        devicesClearButton.setFocusable(false);
        devicesClearButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesClearButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        devicesClearButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                devicesClearButtonMouseClicked(evt);
            }
        });
        jToolBar6.add(devicesClearButton);

        devicesSaveButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/btn_accept.png"))); // NOI18N
        devicesSaveButton.setToolTipText(bundle.getString("Confirm_record")); // NOI18N
        devicesSaveButton.setFocusable(false);
        devicesSaveButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesSaveButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        devicesSaveButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                devicesSaveButtonMouseClicked(evt);
            }
        });
        jToolBar6.add(devicesSaveButton);
        jToolBar6.add(jSeparator5);

        devicesDeleteButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/btn_delete.png"))); // NOI18N
        devicesDeleteButton.setToolTipText(bundle.getString("Delete_record")); // NOI18N
        devicesDeleteButton.setFocusable(false);
        devicesDeleteButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesDeleteButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        devicesDeleteButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                devicesDeleteButtonMouseClicked(evt);
            }
        });
        jToolBar6.add(devicesDeleteButton);
        jToolBar6.add(jSeparator11);

        devicesConsumButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/meter.png"))); // NOI18N
        devicesConsumButton.setToolTipText(bundle.getString("Ny.devicesConsumButton.toolTipText")); // NOI18N
        devicesConsumButton.setFocusable(false);
        devicesConsumButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesConsumButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        devicesConsumButton.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                devicesConsumButtonMouseClicked(evt);
            }
        });
        jToolBar6.add(devicesConsumButton);
        jToolBar6.add(jSeparator16);

        devicesSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/btn_statistic.png"))); // NOI18N
        devicesSearchButton.setToolTipText(bundle.getString("Ny.expensesSearchButton.toolTipText")); // NOI18N
        devicesSearchButton.setFocusable(false);
        devicesSearchButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesSearchButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        devicesSearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                devicesSearchButtonActionPerformed(evt);
            }
        });
        jToolBar6.add(devicesSearchButton);

        devicesSearchState.setFocusable(false);
        devicesSearchState.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesSearchState.setMaximumSize(new java.awt.Dimension(14, 44));
        devicesSearchState.setMinimumSize(new java.awt.Dimension(14, 44));
        devicesSearchState.setPreferredSize(new java.awt.Dimension(14, 44));
        devicesSearchState.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        jToolBar6.add(devicesSearchState);

        devicesNoSearchButton.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons/btn_no_search.png"))); // NOI18N
        devicesNoSearchButton.setToolTipText(bundle.getString("Ny.expensesNoSearchButton.toolTipText")); // NOI18N
        devicesNoSearchButton.setFocusable(false);
        devicesNoSearchButton.setHorizontalTextPosition(javax.swing.SwingConstants.CENTER);
        devicesNoSearchButton.setMaximumSize(new java.awt.Dimension(44, 44));
        devicesNoSearchButton.setMinimumSize(new java.awt.Dimension(44, 44));
        devicesNoSearchButton.setPreferredSize(new java.awt.Dimension(44, 44));
        devicesNoSearchButton.setVerticalTextPosition(javax.swing.SwingConstants.BOTTOM);
        devicesNoSearchButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                devicesNoSearchButtonActionPerformed(evt);
            }
        });
        jToolBar6.add(devicesNoSearchButton);

        gridBagConstraints = new java.awt.GridBagConstraints();
        gridBagConstraints.gridx = 0;
        gridBagConstraints.gridy = 0;
        gridBagConstraints.gridwidth = 6;
        gridBagConstraints.fill = java.awt.GridBagConstraints.HORIZONTAL;
        gridBagConstraints.ipadx = 459;
        gridBagConstraints.anchor = java.awt.GridBagConstraints.NORTHWEST;
        add(jToolBar6, gridBagConstraints);
    }// </editor-fold>//GEN-END:initComponents

private void devicesWTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_devicesWTextFieldKeyTyped
    // allow only numbers a related chars
    Util.checkNumericKey(evt);
}//GEN-LAST:event_devicesWTextFieldKeyTyped

private void devicesOnPeriodTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_devicesOnPeriodTextFieldKeyTyped
    // allow only numbers a related chars
    Util.checkNumericKey(evt);
}//GEN-LAST:event_devicesOnPeriodTextFieldKeyTyped

private void devicesTableMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_devicesTableMouseClicked
    /**Populate TextFields on tab5 (Devices) */
    refreshFields();
}//GEN-LAST:event_devicesTableMouseClicked

private void devicesClearButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_devicesClearButtonMouseClicked
    /** Cleans all textFields on tab5 (Devices)*/
    CleanAllFields();
}//GEN-LAST:event_devicesClearButtonMouseClicked

private void devicesSaveButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_devicesSaveButtonMouseClicked
    /**Insert record on db for table expenses or update it if existing*/
    if (Global.AqID == 0) {
        AppUtil.msgSelectAquarium();
        return;
    }
    String currID = devicesIdTextField.getText();
    
    Device dev=new Device();    
    if (currID == null || currID.equals("")) {
        dev.setId(0);
        } else {                
        dev.setId(Integer.valueOf(currID));
    }
    dev.setName(devicesDeviceTextField.getText());
    dev.setBrand(devicesBrandTextField.getText());
    dev.setWattage(LocUtil.delocalizeDouble(devicesWTextField.getText()));
    dev.setNotes(devicesNotesTextField.getText());
    dev.setOnPeriod(LocUtil.delocalizeDouble(devicesOnPeriodTextField.getText()));
    dev.setQty(LocUtil.delocalizeDouble(devicesQtyTextField.getText()));
    dev.save(dev);
    Device.populateTable(devicesTable);
    CleanAllFields();
}//GEN-LAST:event_devicesSaveButtonMouseClicked

private void devicesDeleteButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_devicesDeleteButtonMouseClicked
    /** Delete selected record on tab5 (devices)*/
    Device.deleteById(devicesIdTextField.getText());
    Device.populateTable(devicesTable);
    CleanAllFields();
}//GEN-LAST:event_devicesDeleteButtonMouseClicked

private void devicesConsumButtonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_devicesConsumButtonMouseClicked
// Show Consumption Statistics
    if (Global.AqID == 0) {
        AppUtil.msgSelectAquarium();
        return;
    }
    InfoDisplay A = new InfoDisplay();
    A.setTitle(java.util.ResourceBundle.getBundle(
            "nyagua/Bundle").getString("CONSUMPTION_STATISTICS"));
    String infos = "";
    try {
        infos = Report.getConsHtm();
    } catch (ClassNotFoundException | SQLException ex) {
        Logger.getLogger(DevicesPanel.class.getName()).log(Level.SEVERE, null, ex);
    }
    A.displayInformations(infos);
    A.setVisible(true);
}//GEN-LAST:event_devicesConsumButtonMouseClicked

private void devicesSearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_devicesSearchButtonActionPerformed
// Search 
    JTextField [] jTF = { devicesDeviceTextField,devicesBrandTextField,
    devicesNotesTextField, devicesOnPeriodTextField, devicesQtyTextField};
    String [] dbFields = {"Device", "Brand","Notes", "OnPeriod", "Qty"}; // NOI18N  
    JTextField [] jTFn = { devicesWTextField};
    String [] dbFieldsn = {"W"}; // NOI18N    
    String filter= DB.createFilter(jTF, dbFields);     
    filter=filter+DB.createNumericFilter(jTFn, dbFieldsn);
    Device.setFilter(filter);
    Device.populateTable(devicesTable);    
    if (Device.getFilter().isEmpty()){
        devicesSearchState.setBackground(Global.BUTTON_GREY);
        devicesSearchState.setToolTipText("");
    } else {
        devicesSearchState.setBackground(Global.BUTTON_RED);
        devicesSearchState.setToolTipText(java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("filter_on")
                +": " + filter);
    }
}//GEN-LAST:event_devicesSearchButtonActionPerformed

private void devicesNoSearchButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_devicesNoSearchButtonActionPerformed
    // Reset  search
    Device.setFilter("");//NOI18N
    Device.populateTable(devicesTable);    
    devicesSearchState.setBackground(Global.BUTTON_GREY);
    devicesSearchState.setToolTipText("");
}//GEN-LAST:event_devicesNoSearchButtonActionPerformed

    private void devicesTableKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_devicesTableKeyReleased
        /*Populate TextFields on tab5 (Devices) */
        refreshFields();
    }//GEN-LAST:event_devicesTableKeyReleased

    private void devicesQtyTextFieldKeyTyped(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_devicesQtyTextFieldKeyTyped
         // allow only numbers a related chars
        Util.checkNumericKey(evt);
    }//GEN-LAST:event_devicesQtyTextFieldKeyTyped

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel devicesBrandLabel;
    private javax.swing.JTextField devicesBrandTextField;
    private javax.swing.JButton devicesClearButton;
    private javax.swing.JButton devicesConsumButton;
    private javax.swing.JButton devicesDeleteButton;
    private javax.swing.JLabel devicesDeviceLabel;
    private javax.swing.JTextField devicesDeviceTextField;
    private javax.swing.JLabel devicesIdLabel;
    private javax.swing.JTextField devicesIdTextField;
    private javax.swing.JButton devicesNoSearchButton;
    private javax.swing.JLabel devicesNotesLabel;
    private javax.swing.JTextField devicesNotesTextField;
    private javax.swing.JLabel devicesOnPeriodLabel;
    private javax.swing.JTextField devicesOnPeriodTextField;
    private javax.swing.JLabel devicesQtyLabel;
    private javax.swing.JTextField devicesQtyTextField;
    private javax.swing.JButton devicesSaveButton;
    private javax.swing.JButton devicesSearchButton;
    private javax.swing.JButton devicesSearchState;
    private static javax.swing.JTable devicesTable;
    private javax.swing.JLabel devicesWLabel;
    private javax.swing.JTextField devicesWTextField;
    private javax.swing.JScrollPane jScrollPane7;
    private javax.swing.JToolBar.Separator jSeparator11;
    private javax.swing.JToolBar.Separator jSeparator16;
    private javax.swing.JToolBar.Separator jSeparator5;
    private javax.swing.JToolBar jToolBar6;
    // End of variables declaration//GEN-END:variables

    /**
     * bind cutandpaste popup menu to text fields
     */
    private void initCutAndPaste(){
        devicesDeviceTextField.addMouseListener(new ContextMenuMouseListener());
        devicesWTextField.addMouseListener(new ContextMenuMouseListener());
        devicesOnPeriodTextField.addMouseListener(new ContextMenuMouseListener());
        devicesBrandTextField.addMouseListener(new ContextMenuMouseListener());
        devicesNotesTextField.addMouseListener(new ContextMenuMouseListener());
        devicesQtyTextField.addMouseListener(new ContextMenuMouseListener());
    }
}
