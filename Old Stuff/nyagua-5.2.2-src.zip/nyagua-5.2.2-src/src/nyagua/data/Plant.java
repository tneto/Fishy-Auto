/*
 * Nyagua - Aquarium Manager
 *    Copyright (C) 2010 Rudi Giacomini Pilon
 *    Copyright (C) 2010 Tom Judge <tom(at)tomjudge.com>
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 */

package nyagua.data;

import java.awt.Font;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Comparator;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableColumn;
import javax.swing.table.TableColumnModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import nyagua.DB;
import nyagua.Global;
import nyagua.LocUtil;
import nyagua.TablesUtil;
import nyagua.Util;

/**
 *
 * @author Rudi Giacomini Pilon
 */
public class Plant {
    public static final String TABLE = "Plants";
    public static final String [] CAPTIONS = {
        java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("ID"),
        java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("DATE"),
        java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("NAME"),
        java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("QTY"),
        java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("INIT_STATUS"),
        java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("NOTES"),
        //java.util.ResourceBundle.getBundle("nyagua/Bundle").getString("AQID")
    };

    // <editor-fold defaultstate="collapsed" desc="fields">
    //private Date date;
    private int id;
    private String name;
    private String date;
    private String quantity;
    private String initialStatus;
    private String notes;
    private Date newDate;
    
    private static final int[] colWidth = new int[CAPTIONS.length];
        
    private static String filter="";
    // </editor-fold>

    // <editor-fold defaultstate="collapsed" desc="Data Access Methods">

    /**
     * @return the id
     */
    public int getId(){
        return id;
    }

    /**
     *
     * @param id the id to set
     */
    public void setId(int id){
        this.id=id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the date
     */
    /*public String getDate() {
        return date;
    }*/

    public Date getDate(){
        return newDate;
    }

    /**
     * @param date the date to set
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     * @return the quantity
     */
    public String getQuantity() {
        return quantity;
    }

    /**
     * @param quantity the quantity to set
     */
    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    /**
     * @return the initialStatus
     */
    public String getInitialStatus() {
        return initialStatus;
    }

    /**
     * @param initialStatus the initialStatus to set
     */
    public void setInitialStatus(String initialStatus) {
        this.initialStatus = initialStatus;
    }

    /**
     * @return the notes
     */
    public String getNotes() {
        return notes;
    }

    /**
     * @param notes the notes to set
     */
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    /**
     * Sets table columns widths' array
     * 
     * @param cw array with the widths
     */
    public static void setColWidth (int [] cw){
        if (cw.length == colWidth.length) {
            System.arraycopy(cw, 0, colWidth, 0, colWidth.length);
        }        
    }
    
    /**
     * @return the filter
     */
    public static String getFilter(){
        return filter;
    }

    /**
     *
     * @param filter the filter to set
     */
    public static void setFilter(String filter){
        Plant.filter=filter;
    }
    // </editor-fold>

    /**
     * get Plant from Db by id
     *
     * @param recId
     * @return Plant
     */
    public static Plant getById (int recId){
        Plant specimen = new Plant();
        String qry = "SELECT * FROM " + TABLE + " WHERE id=" + recId // NOI18N
                + " AND AqID=" + Global.AqID + " ;"; // NOI18N
        ResultSet rs;
        try {
            DB.openConn();
            rs = DB.getQuery(qry);
            while (rs.next()) {
                specimen.id = recId;
                specimen.date = LocUtil.localizeDate(rs.getString("Date")); // NOI18N
                specimen.newDate = LocUtil.localizeAsDate(rs.getString("Date")); // NOI18N
                specimen.name = rs.getString("Name"); // NOI18N                
                specimen.quantity = LocUtil.localizeDouble(rs.getString("Qty")); // NOI18N
                specimen.initialStatus = rs.getString("Init_Status"); // NOI18N
                specimen.notes = rs.getString("Notes"); // NOI18N               
              
            }
            DB.closeConn();           
        } catch (SQLException ex) {
            _log.log(Level.SEVERE, null, ex);
        }
        return specimen; 
    }

    /**
     * Save Plant to db
     * 
     * @param specimen Plant to save
     */
    public void save(Plant specimen){
        int currID=specimen.id;        
        DB.openConn();
        try {
            //Changes due to single quote problem
            PreparedStatement prep=DB.getConn().prepareStatement(""// NOI18N
                    + "INSERT OR REPLACE INTO " + TABLE + " VALUES (?, ?, ?, ?, ?, ?, ?);");// NOI18N
            if (currID == 0) {
                prep.setString(1, null);
            } else {                //the record is in update
                prep.setString(1,  String.valueOf(currID));
            }            
            prep.setString(2,specimen.date);
            prep.setString(3,specimen.name);
            prep.setString(4,specimen.quantity);
            prep.setString(5,specimen.initialStatus);
            prep.setString(6,specimen.notes);
            prep.setInt(7,Global.AqID);
            prep.executeUpdate();            
        } catch (SQLException ex) {
            _log.log(Level.SEVERE, null, ex);
        }        
        //end changes
        //DB.execQuery(qry);
        DB.closeConn();
    }
     
    /**
      * populate a table with datafrom DB
      * 
      * @param displayData the table to populate
      */
    public static void populateTable (JTable displayData){
        try {            
            if (displayData.getColumnCount()>1){ //save col width
                Plant.setColWidth(Util.getColSizes(displayData));
            } 
            TableColumnModel colMod = displayData.getColumnModel();
            int[] orderList = TablesUtil.getOrderList(displayData);
            
            if (orderList.length < CAPTIONS.length) {
                Setting s=Setting.getInstance();
                orderList = s.getTableOrder("plantstable");
            }
            DefaultTableModel dm = new DefaultTableModel();
            displayData.setAutoCreateRowSorter(true);
            DB.openConn();
            String qry = "SELECT COUNT(*) AS cont FROM " + TABLE + "  WHERE AqID ='" 
                    + Global.AqID + "' " + Util.getPeriod()+ " " + filter +  ";"; // NOI18N
            ResultSet rs = DB.getQuery(qry);
            int elements = rs.getInt("cont"); // NOI18N
            int columns = CAPTIONS.length;
            String[][] tableData = new String[elements][columns];
            qry = "SELECT * FROM " + TABLE + "  WHERE AqID ='" + Global.AqID + "' "; // NOI18N
            qry = qry + Util.getPeriod()+ " " + filter  +" ORDER BY Date DESC,id DESC;"; // NOI18N
            rs = DB.getQuery(qry);
            int x = 0;
            while (rs.next()) {
                tableData[x][0] = rs.getString("id");// NOI18N
                tableData[x][1] = LocUtil.localizeDate(rs.getString("Date")); // NOI18N
                tableData[x][2] = rs.getString("Name"); // NOI18N
                tableData[x][3] = LocUtil.localizeDouble(rs.getString("Qty")); // NOI18N
                tableData[x][4] = rs.getString("Init_Status"); // NOI18N
                tableData[x][5] = rs.getString("Notes"); // NOI18N
                
                x++;
            }
            DB.closeConn();
            String[] headerCaptions = TablesUtil.sortHeader(orderList, CAPTIONS);
            dm.setDataVector(tableData,headerCaptions);
            displayData.setModel(dm);
            // Set the first visible column to 40 pixels wide
            TableColumn col = displayData.getColumnModel().getColumn(0);
            int width = 40;
            col.setPreferredWidth(width);
            col = displayData.getColumnModel().getColumn(1);
            width = 140;
            col.setPreferredWidth(width);
            col = displayData.getColumnModel().getColumn(2);
            width = 140;
            col.setPreferredWidth(width);
            TablesUtil.setColSizes(displayData, colWidth);
            TableRowSorter<TableModel> sorter = new TableRowSorter<>(displayData.getModel());
            displayData.setRowSorter(sorter);
            sorter.setComparator(0, new Comparator<String>() { 
                @Override
                public int compare(String s1, String s2) {
                    Integer val1 = Integer.parseInt(s1);
                    Integer val2 = Integer.parseInt(s2);
                    return val1.compareTo(val2);
                }
            });
            sorter.setComparator(1, new Comparator<String>() { 
                @Override
                public int compare(String s1, String s2) {
                    try {
                        Date val1 = LocUtil.localizeAsDate(LocUtil.delocalizeDate(s1));
                        Date val2 = LocUtil.localizeAsDate(LocUtil.delocalizeDate(s2));
                        Long t1= val1.getTime();
                        Long t2= val2.getTime();
                        return t1.compareTo(t2);
                    }
                    catch (Exception e) {
                       _log.log(Level.SEVERE, null, e); 
                    }
                    return s1.compareTo(s2);
                }
            }); 
            JTableHeader header = displayData.getTableHeader();
            header.setFont(new Font("Dialog", Font.BOLD, 12));
             //Order comlumns
            TablesUtil.sortColumns(orderList, displayData, colMod);
            
        } catch (SQLException ex) {
            _log.log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Delete a record from table by id
     *
     * @param recId
     */
    public static void deleteById (String recId){
        DB.DbDelRow(TABLE, recId);// NOI18N
    }
    
    static final Logger _log = Logger.getLogger(Plant.class.getName());

}
